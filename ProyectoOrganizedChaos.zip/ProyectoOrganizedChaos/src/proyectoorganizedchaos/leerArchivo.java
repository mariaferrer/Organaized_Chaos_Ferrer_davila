/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoorganizedchaos;


import java.io.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author mkferrerteran
 */
public class leerArchivo {

    public void leerTxt(String direccion) throws IOException{
        try{
            BufferedReader bf = new BufferedReader(new FileReader(direccion));
            String temp = "";
            String bfRead;
            while((bfRead = bf.readLine()) != null){
                //que se haga el ciclo si bfRead tiene datos
                temp = temp + bfRead; //guarde el texto del archivo  
            }
            String texto = temp;
            
        }catch(FileNotFoundException e){
            System.err.println("No se encontro el archivo");
        }
    }
}
