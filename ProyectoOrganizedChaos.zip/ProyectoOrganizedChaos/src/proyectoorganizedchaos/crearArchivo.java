/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoorganizedchaos;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author mkferrerteran
 */
public class crearArchivo {
    public void amazon() {
        // TODO code application logic here
    File amazon;
    try{
        amazon = new File("/Users/mkferrerteran/Documents/amazon.txt/amazon.txt/");
        
        if(amazon.createNewFile()){
            System.out.println("se creo el archivo");
        }
    } catch(IOException e) {
        System.err.println("No se ha podido crear el archivo");
    }

    }
}
